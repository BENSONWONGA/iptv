# Copyright (c) 2015, Frappe Technologies Pvt. Ltd. and Contributors
# License: MIT. See LICENSE

from contextlib import suppress

import frappe
from frappe import _
from frappe.rate_limiter import rate_limit
from frappe.utils import escape_html, validate_email_address

sitemap = 1


def get_context(context):
	doc = frappe.get_doc("Contact Us Settings", "Contact Us Settings")
	if doc.is_disabled:
		frappe.local.flags.redirect_location = "/404"
		raise frappe.Redirect

	if doc.query_options:
		query_options = [opt.strip() for opt in doc.query_options.replace(",", "\n").split("\n") if opt]
	else:
		query_options = ["Sales", "Support", "General"]

	out = {}
	out.update(doc.as_dict())
	out.update({"query_options": query_options, "parents": [{"name": _("Home"), "route": "/"}]})

	return out


@frappe.whitelist(allow_guest=True)
@rate_limit(limit=100, seconds=60 * 60)
def send_message(sender: str, message: str, subject: str = "Website Query"):
	doc = frappe.get_doc("Contact Us Settings", "Contact Us Settings")
	if doc.is_disabled:
		return

	sender = validate_email_address(sender, throw=True)

	message = escape_html(message)

	with suppress(frappe.OutgoingEmailError):
		if forward_to_email := frappe.db.get_single_value("Contact Us Settings", "forward_to_email"):
			frappe.sendmail(recipients=forward_to_email, reply_to=sender, content=message, subject=subject)

		if frappe.get_single_value("Contact Us Settings", "send_acknowledgement_email"):
			reply = _("Thank you for reaching out to us. We will get back to you at the earliest.")
			frappe.sendmail(
				recipients=sender,
				content=f"<div style='white-space: pre-wrap'>{reply}</div>",
				subject=_("We've received your query!"),
			)

	# for clearing outgoing email error message
	frappe.clear_last_message()

	system_language = frappe.db.get_single_value("System Settings", "language")
	# add to to-do ?
	frappe.get_doc(
		dict(
			doctype="Communication",
			sender=sender,
			subject=_("New Message from Website Contact Page", system_language),
			sent_or_received="Received",
			content=message,
			status="Open",
		)
	).insert(ignore_permissions=True)
